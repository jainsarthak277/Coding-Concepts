#!/bin/bash

count=0
while :
do
	./counter
	((count++));
	cmp --silent actual_output.txt ideal_output/ideal1.txt && continue || cmp --silent actual_output.txt ideal_output/ideal2.txt && continue || break
#	if (cmp --silent actual_output.txt ideal_output/ideal1.txt)
#	then
#		if(cmp --silent actual_output.txt ideal_output/ideal2.txt)
#		then
#			echo "\n\n\n\n"
#			break
#		fi
#	fi
done
echo $'\n'
echo "Variable 'counter' is incremented non-uniformly after $count executions"
