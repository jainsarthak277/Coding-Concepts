Compilation Instructions:
Type 'make' to compile code and 'make clean' to remove object files and executable

Exection Instructions:
1. 	Type './counter' to execute once. Output shows which cpu each thread runs on, and the value of 'counter' variable after each thread is done executing.
	Output is generally expected to 5000 and 10000. However, every once in 4-5 executions, output comes out to be different.

2. Type './checkscript' to run an automated test script which keeps executing the code until a discrepant output is obtained.
